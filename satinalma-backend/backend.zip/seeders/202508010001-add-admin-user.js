'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    // Eğer id=1 olan bir kullanıcı yoksa ekle
    const [users] = await queryInterface.sequelize.query('SELECT id FROM Users WHERE id = 1');
    if (users.length === 0) {
      await queryInterface.bulkInsert('Users', [
        {
          id: 1,
          username: 'admin',
          firstName: 'Admin',
          lastName: 'User',
          email: 'admin@example.com',
          password: '$2b$10$123456789012345678901uQwQwQwQwQwQwQwQwQwQwQwQwQwQwQwQwQwQwQwQwQw', // dummy hash
          department: 'IT',
          role: 'admin',
          status: 'active',
          mustChangePassword: false,
          createdAt: new Date(),
          updatedAt: new Date()
        }
      ]);
    }
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.bulkDelete('Users', { id: 1 });
  }
};
