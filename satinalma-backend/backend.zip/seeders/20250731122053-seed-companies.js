'use strict';
const fs = require('fs');
const path = require('path');
const XLSX = require('xlsx'); // CSV parser yerine XLSX kütüphanesini kullanıyoruz

/**
 * XLSX dosyalarından benzersiz firma isimlerini okur.
 * @returns {Promise<Array<Object>>} Veritabanına eklenecek firma objeleri dizisi.
 */
async function getUniqueCompaniesFromXLSX() {
  const dataPath = path.join(process.cwd(), 'data');
  const files = [
    'data1.xlsx',
    'data2.xlsx',
    'data3.xlsx',
    'data4.xlsx'
  ];

  const companyNames = new Set(); // Tekrar edenleri engellemek için Set kullanıyoruz.

  for (const file of files) {
    const filePath = path.join(dataPath, file);
    
    if (!fs.existsSync(filePath)) {
      console.warn(`UYARI: ${file} dosyası '${dataPath}' konumunda bulunamadı, atlanıyor.`);
      continue;
    }

    // Excel dosyasını oku
    const workbook = XLSX.readFile(filePath);
    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];
    
    // Sayfayı satır satır JSON'a çevir (header: 1 ile her satır bir dizi olur)
    const data = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

    // İlk satır başlık olduğu için atlayarak başla (i=1)
    for (let i = 1; i < data.length; i++) {
      const row = data[i];
      const companyName = row[0]?.trim(); // İlk sütunu (A sütunu) al

      if (companyName && companyName.length > 1) {
        companyNames.add(companyName);
      }
    }
  }

  console.log(`Toplam ${companyNames.size} adet benzersiz firma bulundu.`);

  // Veritabanına eklenecek formatta obje dizisi oluştur
  return Array.from(companyNames).map(name => ({
    name: name,
    type: 'customer',
    created_at: new Date(),
    updated_at: new Date()
  }));
}

module.exports = {
  up: async (queryInterface, Sequelize) => {
    try {
      const companies = await getUniqueCompaniesFromXLSX();
      if (companies.length > 0) {
        // 'ignoreDuplicates' seçeneği, veritabanında zaten var olan kayıtları atlar.
        await queryInterface.bulkInsert('companies', companies, { ignoreDuplicates: true });
        console.log(`✅ ${companies.length} firma başarıyla veritabanına eklendi.`);
      } else {
        console.log('ℹ️ Veritabanına eklenecek yeni firma bulunamadı.');
      }
    } catch (error) {
      console.error('❌ Seeder çalıştırılırken hata oluştu:', error);
    }
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.bulkDelete('companies', null, {});
  }
};
