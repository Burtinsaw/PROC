// backend/config/config.js - SQLite VERSİYONU
require('dotenv').config(); // .env dosyasını yükle

module.exports = {
  development: {
    dialect: process.env.DB_DIALECT || 'sqlite',
    storage: process.env.DB_STORAGE || './database.sqlite',
    logging: false // Konsola SQL sorgularını yazdırmayı kapat
  },
  test: {
    dialect: 'sqlite',
    storage: './database_test.sqlite',
    logging: false
  },
  production: {
    dialect: process.env.DB_DIALECT || 'sqlite',
    storage: process.env.DB_STORAGE || './database_production.sqlite',
    logging: false
  }
};

