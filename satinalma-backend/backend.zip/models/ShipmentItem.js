'use strict';
const { Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  class ShipmentItem extends Model {
    static associate(models) {
      this.belongsTo(models.Shipment, { foreignKey: 'shipmentId', as: 'shipment' });
      this.belongsTo(models.PurchaseOrderItem, { foreignKey: 'purchaseOrderItemId', as: 'purchaseOrderItem' });
    }
  }

  ShipmentItem.init({
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    shipmentId: { type: DataTypes.INTEGER, allowNull: false },
    purchaseOrderItemId: { type: DataTypes.INTEGER, allowNull: false },
    quantity: { type: DataTypes.INTEGER, allowNull: false },
    condition: {
      type: DataTypes.ENUM,
      values: ['good', 'damaged', 'missing'],
      defaultValue: 'good'
    },
    notes: { type: DataTypes.TEXT }
  }, {
    sequelize,
    modelName: 'ShipmentItem',
    tableName: 'shipment_items',
    timestamps: true
  });

  return ShipmentItem;
};
