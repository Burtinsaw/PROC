'use strict';
const { Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  class Talep extends Model {
    static associate(models) {
      this.hasMany(models.TalepUrun, { foreignKey: 'talepId', as: 'urunler' });
      this.hasMany(models.Offer, { foreignKey: 'talepId', as: 'offers' });
      this.belongsTo(models.User, { foreignKey: 'userId', as: 'user' });
    }
  }

  Talep.init({
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    talepNo: { type: DataTypes.STRING, unique: true },
    talepBasligi: { type: DataTypes.STRING, allowNull: false },
    firma: { type: DataTypes.STRING, allowNull: false },
    talepKaynagi: { type: DataTypes.STRING, defaultValue: 'yurtdisi' },
    oncelik: { type: DataTypes.STRING, defaultValue: 'orta' },
    // *** HATA BURADA DÜZELTİLDİ: 'status' alanı 'durum' olarak değiştirildi ***
    durum: { type: DataTypes.STRING, defaultValue: 'taslak' },
    aciklama: { type: DataTypes.TEXT },
    talepSahibiAd: { type: DataTypes.STRING },
    isEmriAcanDepartman: { type: DataTypes.STRING },
    userId: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 1 },
    // ID Takip Sistemi Alanları
    tracking_id: { 
      type: DataTypes.STRING,
      field: 'tracking_id',
      comment: 'Mevcut takip ID - Proforma onaylandığında proforma numarası olur'
    },
    proforma_number: {
      type: DataTypes.STRING,
      field: 'proforma_number',
      comment: 'İlişkili proforma numarası'
    },
    tracking_phase: {
      type: DataTypes.ENUM('request_phase', 'proforma_created', 'proforma_approved', 'purchasing_phase', 'logistics_phase', 'customs_phase', 'completed'),
      field: 'tracking_phase',
      defaultValue: 'request_phase',
      comment: 'Hangi aşamada olduğunu belirtir'
    }
  }, {
    sequelize,
    modelName: 'Talep',
    tableName: 'talepler',
    timestamps: true,
    paranoid: true,
  });

  return Talep;
};
