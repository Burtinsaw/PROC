'use strict';
const { Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  class PurchaseOrder extends Model {
    static associate(models) {
      // Bir purchase order bir talepten oluşur
      this.belongsTo(models.Talep, { foreignKey: 'talepId', as: 'talep' });
      // Purchase order'ın ürünleri
      this.hasMany(models.PurchaseOrderItem, { foreignKey: 'purchaseOrderId', as: 'items' });
      // Purchase order'ı oluşturan kullanıcı
      this.belongsTo(models.User, { foreignKey: 'createdById', as: 'createdBy' });
      // Tedarikçi firma
      this.belongsTo(models.Company, { foreignKey: 'supplierId', as: 'supplier' });
      // Lojistik takibi
      this.hasMany(models.Shipment, { foreignKey: 'purchaseOrderId', as: 'shipments' });
      // Faturalar
      this.hasMany(models.Invoice, { foreignKey: 'purchaseOrderId', as: 'invoices' });
    }
  }

  PurchaseOrder.init({
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    poNumber: { type: DataTypes.STRING, unique: true, allowNull: false }, // PO-2025-001
    talepId: { type: DataTypes.INTEGER, allowNull: false },
    supplierId: { type: DataTypes.INTEGER, allowNull: false },
    status: { 
      type: DataTypes.ENUM,
      values: ['draft', 'sent', 'confirmed', 'partially_delivered', 'delivered', 'cancelled'],
      defaultValue: 'draft'
    },
    totalAmount: { type: DataTypes.DECIMAL(15, 2) },
    currency: { type: DataTypes.STRING, defaultValue: 'USD' },
    deliveryDate: { type: DataTypes.DATE },
    deliveryAddress: { type: DataTypes.TEXT },
    terms: { type: DataTypes.TEXT },
    notes: { type: DataTypes.TEXT },
    createdById: { type: DataTypes.INTEGER, allowNull: false },
    sentDate: { type: DataTypes.DATE },
    confirmedDate: { type: DataTypes.DATE },
    // ID Takip Sistemi
    trackingId: { 
      type: DataTypes.STRING,
      comment: 'Takip ID - Proforma onaylandığında proforma numarası'
    }
  }, {
    sequelize,
    modelName: 'PurchaseOrder',
    tableName: 'purchase_orders',
    timestamps: true
  });

  return PurchaseOrder;
};
