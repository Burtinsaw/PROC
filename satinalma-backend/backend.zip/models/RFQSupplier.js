'use strict';
const { Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  class RFQSupplier extends Model {
    static associate(models) {
      // RFQSupplier bir RFQ'ya ait
      this.belongsTo(models.RFQ, { foreignKey: 'rfqId', as: 'rfq' });
      // RFQSupplier bir tedarikçiye ait
      this.belongsTo(models.Company, { foreignKey: 'supplierId', as: 'supplier' });
    }
  }

  RFQSupplier.init({
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    rfqId: { type: DataTypes.INTEGER, allowNull: false },
    supplierId: { type: DataTypes.INTEGER, allowNull: false },
    sentDate: { type: DataTypes.DATE },
    emailStatus: {
      type: DataTypes.ENUM,
      values: ['pending', 'sent', 'failed', 'bounced'],
      defaultValue: 'pending'
    }
  }, {
    sequelize,
    modelName: 'RFQSupplier',
    tableName: 'rfq_suppliers',
    timestamps: true,
    indexes: [
      {
        unique: true,
        fields: ['rfqId', 'supplierId']
      }
    ]
  });

  return RFQSupplier;
};
