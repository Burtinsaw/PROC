'use strict';
const { Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  class PurchaseOrderItem extends Model {
    static associate(models) {
      this.belongsTo(models.PurchaseOrder, { foreignKey: 'purchaseOrderId', as: 'purchaseOrder' });
      // Orijinal talep ürününe referans
      this.belongsTo(models.TalepUrun, { foreignKey: 'talepUrunId', as: 'talepUrun' });
    }
  }

  PurchaseOrderItem.init({
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    purchaseOrderId: { type: DataTypes.INTEGER, allowNull: false },
    talepUrunId: { type: DataTypes.INTEGER },
    productName: { type: DataTypes.STRING, allowNull: false },
    productDescription: { type: DataTypes.TEXT },
    quantity: { type: DataTypes.INTEGER, allowNull: false },
    unit: { type: DataTypes.STRING, defaultValue: 'adet' },
    unitPrice: { type: DataTypes.DECIMAL(15, 2) },
    totalPrice: { type: DataTypes.DECIMAL(15, 2) },
    deliveredQuantity: { type: DataTypes.INTEGER, defaultValue: 0 },
    brand: { type: DataTypes.STRING },
    articleNumber: { type: DataTypes.STRING }
  }, {
    sequelize,
    modelName: 'PurchaseOrderItem',
    tableName: 'purchase_order_items',
    timestamps: true
  });

  return PurchaseOrderItem;
};
