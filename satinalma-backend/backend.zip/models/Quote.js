'use strict';
const { Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  class Quote extends Model {
    static associate(models) {
      this.belongsTo(models.RFQ, { foreignKey: 'rfqId', as: 'rfq' });
      this.belongsTo(models.Company, { foreignKey: 'supplierId', as: 'supplier' });
      this.hasMany(models.QuoteItem, { foreignKey: 'quoteId', as: 'items' });
      this.belongsTo(models.User, { foreignKey: 'receivedById', as: 'receivedBy' });
    }
  }

  Quote.init({
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    quoteNumber: { type: DataTypes.STRING, unique: true, allowNull: false }, // QT-2025-001-SUP1
    rfqId: { type: DataTypes.INTEGER, allowNull: false },
    supplierId: { type: DataTypes.INTEGER, allowNull: false },
    supplierQuoteNumber: { type: DataTypes.STRING }, // Tedarikçinin kendi teklif numarası
    status: {
      type: DataTypes.ENUM,
      values: ['received', 'under_review', 'approved', 'rejected', 'selected'],
      defaultValue: 'received'
    },
    totalAmount: { type: DataTypes.DECIMAL(15, 2) },
    currency: { type: DataTypes.STRING, defaultValue: 'USD' },
    validUntil: { type: DataTypes.DATE },
    paymentTerms: { type: DataTypes.STRING },
    deliveryTerms: { type: DataTypes.STRING },
    deliveryTime: { type: DataTypes.STRING }, // "2-3 hafta"
    warranty: { type: DataTypes.STRING },
    notes: { type: DataTypes.TEXT },
    incoterms: { type: DataTypes.STRING }, // FOB, CIF, etc.
    
    // Değerlendirme skorları
    priceScore: { type: DataTypes.DECIMAL(3, 1) }, // 0-10
    qualityScore: { type: DataTypes.DECIMAL(3, 1) },
    deliveryScore: { type: DataTypes.DECIMAL(3, 1) },
    serviceScore: { type: DataTypes.DECIMAL(3, 1) },
    overallScore: { type: DataTypes.DECIMAL(3, 1) },
    
    evaluationNotes: { type: DataTypes.TEXT },
    receivedDate: { type: DataTypes.DATE, defaultValue: DataTypes.NOW },
    receivedById: { type: DataTypes.INTEGER }
  }, {
    sequelize,
    modelName: 'Quote',
    tableName: 'quotes',
    timestamps: true
  });

  return Quote;
};
