'use strict';
const { Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  class Document extends Model {
    static associate(models) {
      // Polymorphic association - bir doküman farklı entity'lere ait olabilir
      this.belongsTo(models.Talep, { foreignKey: 'entityId', constraints: false, scope: { entityType: 'Talep' } });
      this.belongsTo(models.PurchaseOrder, { foreignKey: 'entityId', constraints: false, scope: { entityType: 'PurchaseOrder' } });
      this.belongsTo(models.Shipment, { foreignKey: 'entityId', constraints: false, scope: { entityType: 'Shipment' } });
      this.belongsTo(models.Invoice, { foreignKey: 'entityId', constraints: false, scope: { entityType: 'Invoice' } });
      this.belongsTo(models.User, { foreignKey: 'uploadedById', as: 'uploadedBy' });
    }
  }

  Document.init({
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    entityType: { 
      type: DataTypes.ENUM,
      values: ['Talep', 'PurchaseOrder', 'Shipment', 'Invoice', 'Payment'],
      allowNull: false
    },
    entityId: { type: DataTypes.INTEGER, allowNull: false },
    documentType: {
      type: DataTypes.ENUM,
      values: [
        'request_document',      // Talep ile ilgili dokümanlar
        'quotation',            // Tedarikçi teklifleri
        'purchase_order',       // Satın alma siparişleri
        'proforma_invoice',     // Proforma faturalar
        'commercial_invoice',   // Ticari faturalar
        'packing_list',         // Paketleme listeleri
        'bill_of_lading',       // Konşimento
        'customs_declaration',  // Gümrük beyannamesi
        'delivery_receipt',     // Teslimat makbuzu
        'payment_receipt',      // Ödeme makbuzu
        'certificate',          // Sertifikalar
        'other'
      ],
      allowNull: false
    },
    fileName: { type: DataTypes.STRING, allowNull: false },
    originalFileName: { type: DataTypes.STRING, allowNull: false },
    filePath: { type: DataTypes.STRING, allowNull: false },
    fileSize: { type: DataTypes.INTEGER },
    mimeType: { type: DataTypes.STRING },
    description: { type: DataTypes.TEXT },
    tags: { type: DataTypes.JSON }, // ['urgent', 'customs', 'quality_check']
    version: { type: DataTypes.INTEGER, defaultValue: 1 },
    isActive: { type: DataTypes.BOOLEAN, defaultValue: true },
    uploadedById: { type: DataTypes.INTEGER, allowNull: false }
  }, {
    sequelize,
    modelName: 'Document',
    tableName: 'documents',
    timestamps: true,
    indexes: [
      { fields: ['entityType', 'entityId'] },
      { fields: ['documentType'] },
      { fields: ['uploadedById'] }
    ]
  });

  return Document;
};
