'use strict';
const { Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  class TalepUrun extends Model {
    static associate(models) {
      // Her ürün, bir talebe aittir.
      this.belongsTo(models.Talep, {
        foreignKey: 'talepId',
        as: 'talep',
      });
    }
  }

  TalepUrun.init({
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    urunAdi: { type: DataTypes.STRING, allowNull: false },
    miktar: { type: DataTypes.DECIMAL(10, 3), allowNull: false, defaultValue: 1 },
    birim: { type: DataTypes.STRING, allowNull: false, defaultValue: 'Adet' },
    marka: { type: DataTypes.STRING },
    model: { type: DataTypes.STRING },
    ozellikler: { type: DataTypes.TEXT },
    talepId: { type: DataTypes.INTEGER, allowNull: false }
  }, {
    sequelize,
    modelName: 'TalepUrun',
    tableName: 'talep_urunler',
    timestamps: true,
    paranoid: true, // soft delete için
  });

  return TalepUrun;
};
