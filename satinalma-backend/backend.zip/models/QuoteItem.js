'use strict';
const { Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  class QuoteItem extends Model {
    static associate(models) {
      this.belongsTo(models.Quote, { foreignKey: 'quoteId', as: 'quote' });
      this.belongsTo(models.RFQItem, { foreignKey: 'rfqItemId', as: 'rfqItem' });
    }
  }

  QuoteItem.init({
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    quoteId: { type: DataTypes.INTEGER, allowNull: false },
    rfqItemId: { type: DataTypes.INTEGER, allowNull: false },
    productName: { type: DataTypes.STRING, allowNull: false },
    productDescription: { type: DataTypes.TEXT },
    brand: { type: DataTypes.STRING },
    model: { type: DataTypes.STRING },
    articleNumber: { type: DataTypes.STRING },
    quantity: { type: DataTypes.INTEGER, allowNull: false },
    unit: { type: DataTypes.STRING, defaultValue: 'adet' },
    unitPrice: { type: DataTypes.DECIMAL(15, 2), allowNull: false },
    totalPrice: { type: DataTypes.DECIMAL(15, 2), allowNull: false },
    currency: { type: DataTypes.STRING, defaultValue: 'USD' },
    deliveryTime: { type: DataTypes.STRING },
    warranty: { type: DataTypes.STRING },
    technicalSpecification: { type: DataTypes.TEXT },
    countryOfOrigin: { type: DataTypes.STRING },
    
    // Alternatif ürün bilgisi
    isAlternative: { type: DataTypes.BOOLEAN, defaultValue: false },
    alternativeReason: { type: DataTypes.STRING },
    
    // Değerlendirme
    technicalCompliance: {
      type: DataTypes.ENUM,
      values: ['fully_compliant', 'partially_compliant', 'non_compliant'],
      allowNull: true
    },
    complianceNotes: { type: DataTypes.TEXT },
    
    notes: { type: DataTypes.TEXT }
  }, {
    sequelize,
    modelName: 'QuoteItem',
    tableName: 'quote_items',
    timestamps: true
  });

  return QuoteItem;
};
