'use strict';
const { Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  class EmailMessage extends Model {
    static associate(models) {
      // Email mesaj ilişkileri burada tanımlanabilir
      this.belongsTo(models.User, {
        foreignKey: 'userId',
        as: 'user'
      });
    }
  }

  EmailMessage.init({
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    subject: {
      type: DataTypes.STRING,
      allowNull: false
    },
    body: {
      type: DataTypes.TEXT,
      allowNull: false
    },
    fromEmail: {
      type: DataTypes.STRING,
      allowNull: false
    },
    toEmail: {
      type: DataTypes.STRING,
      allowNull: false
    },
    status: {
      type: DataTypes.ENUM('sent', 'delivered', 'failed'),
      defaultValue: 'sent'
    },
    userId: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'Users',
        key: 'id'
      }
    }
  }, {
    sequelize,
    modelName: 'EmailMessage',
    tableName: 'EmailMessages',
    timestamps: true
  });

  return EmailMessage;
};