'use strict';
const { Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  class Offer extends Model {
    static associate(models) {
      this.belongsTo(models.Talep, {
        foreignKey: 'talepId',
        as: 'talep',
      });
      this.belongsTo(models.Company, {
        foreignKey: 'companyId',
        as: 'supplierCompany',
      });
    }
  }

  Offer.init({
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    talepId: { type: DataTypes.INTEGER, allowNull: false },
    companyId: { type: DataTypes.INTEGER, allowNull: true },
    supplierName: { type: DataTypes.STRING, allowNull: false },
    price: { type: DataTypes.DECIMAL(15, 2), allowNull: false },
    currency: { type: DataTypes.STRING(10), allowNull: false, defaultValue: 'USD' },
    // *** HATA BURADA DÜZELTİLDİ: 'deliveryDate' alanı 'deliveryTime' olarak değiştirildi ***
    deliveryTime: {
      type: DataTypes.STRING,
    },
    status: {
      type: DataTypes.STRING,
      allowNull: false,
      defaultValue: 'pending',
    },
    notes: {
      type: DataTypes.TEXT,
    },
    isBestOffer: {
      type: DataTypes.BOOLEAN,
      defaultValue: false,
    }
  }, {
    sequelize,
    modelName: 'Offer',
    tableName: 'offers',
    timestamps: true,
  });

  return Offer;
};
