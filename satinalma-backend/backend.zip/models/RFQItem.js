'use strict';
const { Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  class RFQItem extends Model {
    static associate(models) {
      this.belongsTo(models.RFQ, { foreignKey: 'rfqId', as: 'rfq' });
      this.belongsTo(models.TalepUrun, { foreignKey: 'talepUrunId', as: 'talepUrun' });
      // Bu item için gelen teklifler
      this.hasMany(models.QuoteItem, { foreignKey: 'rfqItemId', as: 'quoteItems' });
    }
  }

  RFQItem.init({
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    rfqId: { type: DataTypes.INTEGER, allowNull: false },
    talepUrunId: { type: DataTypes.INTEGER, allowNull: true },
    urunAdi: { type: DataTypes.STRING, allowNull: false },
    miktar: { type: DataTypes.DECIMAL(10, 2), allowNull: false },
    birim: { type: DataTypes.STRING, allowNull: false },
    unit: { type: DataTypes.STRING, allowNull: true }, // Hem Türkçe hem İngilizce destek
    teknikOzellikler: { type: DataTypes.TEXT },
    marka: { type: DataTypes.STRING },
    model: { type: DataTypes.STRING }
  }, {
    sequelize,
    modelName: 'RFQItem',
    tableName: 'rfq_items',
    timestamps: true
  });

  return RFQItem;
};
