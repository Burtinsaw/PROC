'use strict';
const { Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  class Shipment extends Model {
    static associate(models) {
      this.belongsTo(models.PurchaseOrder, { foreignKey: 'purchaseOrderId', as: 'purchaseOrder' });
      this.hasMany(models.ShipmentItem, { foreignKey: 'shipmentId', as: 'items' });
      this.belongsTo(models.User, { foreignKey: 'createdById', as: 'createdBy' });
    }
  }

  Shipment.init({
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    shipmentNumber: { type: DataTypes.STRING, unique: true, allowNull: false },
    purchaseOrderId: { type: DataTypes.INTEGER, allowNull: false },
    trackingNumber: { type: DataTypes.STRING },
    carrier: { type: DataTypes.STRING }, // DHL, FedEx, TNT etc.
    status: {
      type: DataTypes.ENUM,
      values: ['preparing', 'shipped', 'in_transit', 'customs', 'delivered', 'delayed', 'returned'],
      defaultValue: 'preparing'
    },
    shipDate: { type: DataTypes.DATE },
    estimatedDeliveryDate: { type: DataTypes.DATE },
    actualDeliveryDate: { type: DataTypes.DATE },
    origin: { type: DataTypes.STRING },
    destination: { type: DataTypes.STRING },
    weight: { type: DataTypes.DECIMAL(10, 2) },
    dimensions: { type: DataTypes.STRING },
    customsValue: { type: DataTypes.DECIMAL(15, 2) },
    customsStatus: {
      type: DataTypes.ENUM,
      values: ['pending', 'cleared', 'held', 'rejected'],
      allowNull: true
    },
    notes: { type: DataTypes.TEXT },
    createdById: { type: DataTypes.INTEGER, allowNull: false },
    // ID Takip Sistemi
    trackingId: { 
      type: DataTypes.STRING,
      comment: 'Takip ID - Proforma onaylandığında proforma numarası'
    }
  }, {
    sequelize,
    modelName: 'Shipment',
    tableName: 'shipments',
    timestamps: true
  });

  return Shipment;
};
