'use strict';
const { Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  class Company extends Model {
    static associate(models) {
      // Eğer Company modelinin diğer modellerle ilişkisi varsa, buraya eklenir.
    }
  }

  Company.init({
    // Modelinizin alan tanımlamaları
    name: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true
    },
    code: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true
    },
    address: {
      type: DataTypes.STRING
    },
    email: {
      type: DataTypes.STRING
    },
    phone: {
      type: DataTypes.STRING
    },
    tax_office: {
      type: DataTypes.STRING
    },
    tax_number: {
      type: DataTypes.STRING
    },
    type: {
      type: DataTypes.ENUM(
        'customer', 
        'supplier', 
        'carrier', 
        'main', 
        'broker', 
        'importer', 
        'exporter', 
        'distributor', 
        'logistics_partner'
      ),
      allowNull: false,
      defaultValue: 'customer',
      comment: 'Firma tipi: customer=müşteri, supplier=tedarikçi, carrier=nakliyeci, main=ana firma, broker=aracı, importer=ithalatçı, exporter=ihracatçı, distributor=distribütör, logistics_partner=lojistik partner'
    },
    inn: {
      type: DataTypes.STRING
    },
    kpp: {
      type: DataTypes.STRING
    },
    ogrn: {
      type: DataTypes.STRING
    },
    vat: {
      type: DataTypes.STRING
    },
    uscc: {
      type: DataTypes.STRING
    },
    // Broker/Aracılık Sistemi Alanları
    business_model: {
      type: DataTypes.STRING,
      defaultValue: 'direct_trade'
    },
    commission_rate: {
      type: DataTypes.DECIMAL(5, 2),
      defaultValue: 0.00
    },
    credit_limit: {
      type: DataTypes.DECIMAL(15, 2),
      defaultValue: 0.00
    },
    service_areas: {
      type: DataTypes.TEXT,
      get() {
        const value = this.getDataValue('service_areas');
        return value ? JSON.parse(value) : [];
      },
      set(value) {
        this.setDataValue('service_areas', Array.isArray(value) ? JSON.stringify(value) : value);
      }
    },
    specializations: {
      type: DataTypes.TEXT,
      get() {
        const value = this.getDataValue('specializations');
        return value ? JSON.parse(value) : [];
      },
      set(value) {
        this.setDataValue('specializations', Array.isArray(value) ? JSON.stringify(value) : value);
      }
    },
    partner_companies: {
      type: DataTypes.TEXT,
      get() {
        const value = this.getDataValue('partner_companies');
        return value ? JSON.parse(value) : [];
      },
      set(value) {
        this.setDataValue('partner_companies', Array.isArray(value) ? JSON.stringify(value) : value);
      }
    }
  }, {
    sequelize,
    modelName: 'Company',
    tableName: 'companies',
    timestamps: true,
    underscored: true,
    hooks: {
      beforeValidate: async (company, options) => {
        if (company.isNewRecord && !company.code) {
          const last = await Company.findOne({
            order: [['created_at', 'DESC']]
          });
          let nextNum = 1;
          if (last && last.code && /^COMP\d+$/.test(last.code)) {
            nextNum = parseInt(last.code.replace('COMP', ''), 10) + 1;
          }
          company.code = `COMP${String(nextNum).padStart(3, '0')}`;
        }
      }
    }
  });

  return Company;
};
