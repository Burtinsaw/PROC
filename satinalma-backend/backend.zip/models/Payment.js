'use strict';
const { Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  class Payment extends Model {
    static associate(models) {
      this.belongsTo(models.Invoice, { foreignKey: 'invoiceId', as: 'invoice' });
      this.belongsTo(models.User, { foreignKey: 'createdById', as: 'createdBy' });
    }
  }

  Payment.init({
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    invoiceId: { type: DataTypes.INTEGER, allowNull: false },
    paymentNumber: { type: DataTypes.STRING, unique: true, allowNull: false },
    paymentDate: { type: DataTypes.DATE, allowNull: false },
    amount: { type: DataTypes.DECIMAL(15, 2), allowNull: false },
    currency: { type: DataTypes.STRING, defaultValue: 'USD' },
    paymentMethod: {
      type: DataTypes.ENUM,
      values: ['bank_transfer', 'credit_card', 'check', 'cash', 'letter_of_credit'],
      allowNull: false
    },
    transactionReference: { type: DataTypes.STRING },
    bankDetails: { type: DataTypes.TEXT },
    status: {
      type: DataTypes.ENUM,
      values: ['pending', 'completed', 'failed', 'cancelled'],
      defaultValue: 'pending'
    },
    notes: { type: DataTypes.TEXT },
    createdById: { type: DataTypes.INTEGER, allowNull: false },
    // ID Takip Sistemi
    trackingId: { 
      type: DataTypes.STRING,
      comment: 'Takip ID - Proforma onaylandığında proforma numarası'
    }
  }, {
    sequelize,
    modelName: 'Payment',
    tableName: 'payments',
    timestamps: true
  });

  return Payment;
};
