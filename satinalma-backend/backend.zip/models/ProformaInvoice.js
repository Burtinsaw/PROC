module.exports = (sequelize, DataTypes) => {
const ProformaInvoice = sequelize.define('ProformaInvoice', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  proformaNumber: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true,
    comment: 'Proforma fatura numarası'
  },
  quoteId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'Quotes',
      key: 'id'
    },
    comment: 'Temel alınan teklif ID'
  },
  companyId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'Companies',
      key: 'id'
    },
    comment: 'Proformayı alan firma ID'
  },
  currency: {
    type: DataTypes.ENUM('EUR', 'USD', 'RUB', 'CNY', 'TRY'),
    allowNull: false,
    defaultValue: 'EUR',
    comment: 'Para birimi'
  },
  profitMargin: {
    type: DataTypes.DECIMAL(5, 2),
    allowNull: false,
    validate: {
      min: 2.5
    },
    comment: 'Kar oranı (minimum %2.5)'
  },
  subtotal: {
    type: DataTypes.DECIMAL(15, 2),
    allowNull: false,
    comment: 'Ara toplam (kar oranı dahil)'
  },
  taxRate: {
    type: DataTypes.DECIMAL(5, 2),
    defaultValue: 0,
    comment: 'KDV oranı'
  },
  taxAmount: {
    type: DataTypes.DECIMAL(15, 2),
    defaultValue: 0,
    comment: 'KDV tutarı'
  },
  totalAmount: {
    type: DataTypes.DECIMAL(15, 2),
    allowNull: false,
    comment: 'Toplam tutar'
  },
  validUntil: {
    type: DataTypes.DATE,
    allowNull: false,
    comment: 'Geçerlilik tarihi'
  },
  status: {
    type: DataTypes.ENUM('draft', 'sent', 'accepted', 'rejected', 'expired'),
    defaultValue: 'draft',
    comment: 'Proforma durumu'
  },
  notes: {
    type: DataTypes.TEXT,
    comment: 'Notlar ve özel şartlar'
  },
  paymentTerms: {
    type: DataTypes.STRING,
    comment: 'Ödeme şartları'
  },
  deliveryTerms: {
    type: DataTypes.STRING,
    comment: 'Teslimat şartları'
  },
  createdBy: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'Users',
      key: 'id'
    }
  },
  sentAt: {
    type: DataTypes.DATE,
    comment: 'Gönderilme tarihi'
  }
}, {
  tableName: 'proforma_invoices',
  timestamps: true,
  hooks: {
    beforeCreate: async (proforma) => {
      // Otomatik proforma numarası oluştur
      const year = new Date().getFullYear();
      const month = String(new Date().getMonth() + 1).padStart(2, '0');
      const count = await ProformaInvoice.count({
        where: {
          createdAt: {
            [sequelize.Sequelize.Op.gte]: new Date(year, 0, 1),
            [sequelize.Sequelize.Op.lt]: new Date(year + 1, 0, 1)
          }
        }
      });
      const serialNumber = String(count + 1).padStart(4, '0');
      proforma.proformaNumber = `PF${year}${month}-${serialNumber}`;
    }
  }
});

// Model ilişkileri
ProformaInvoice.associate = function(models) {
  // ProformaInvoice -> Quote (N:1)
  ProformaInvoice.belongsTo(models.Quote, {
    foreignKey: 'quoteId',
    as: 'Quote'
  });

  // ProformaInvoice -> Company (N:1)
  ProformaInvoice.belongsTo(models.Company, {
    foreignKey: 'companyId',
    as: 'Company'
  });

  // ProformaInvoice -> User (N:1)
  ProformaInvoice.belongsTo(models.User, {
    foreignKey: 'createdBy',
    as: 'Creator'
  });

  // ProformaInvoice -> ProformaInvoiceItem (1:N)
  ProformaInvoice.hasMany(models.ProformaInvoiceItem, {
    foreignKey: 'proformaInvoiceId',
    as: 'ProformaInvoiceItems'
  });
};

return ProformaInvoice;
};
