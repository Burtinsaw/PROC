module.exports = (sequelize, DataTypes) => {
const ProformaInvoiceItem = sequelize.define('ProformaInvoiceItem', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  proformaInvoiceId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'ProformaInvoices',
      key: 'id'
    }
  },
  quoteItemId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'QuoteItems',
      key: 'id'
    },
    comment: 'Temel alınan teklif kalemi ID'
  },
  productName: {
    type: DataTypes.STRING,
    allowNull: false,
    comment: 'Ürün adı'
  },
  description: {
    type: DataTypes.TEXT,
    comment: 'Ürün açıklaması'
  },
  quantity: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false,
    comment: 'Miktar'
  },
  unit: {
    type: DataTypes.STRING(50),
    allowNull: false,
    comment: 'Birim'
  },
  unitPrice: {
    type: DataTypes.DECIMAL(15, 2),
    allowNull: false,
    comment: 'Birim fiyat (kar oranı dahil)'
  },
  originalUnitPrice: {
    type: DataTypes.DECIMAL(15, 2),
    allowNull: false,
    comment: 'Orijinal birim fiyat (kar oranı hariç)'
  },
  lineTotal: {
    type: DataTypes.DECIMAL(15, 2),
    allowNull: false,
    comment: 'Satır toplamı'
  },
  brand: {
    type: DataTypes.STRING,
    comment: 'Marka'
  },
  model: {
    type: DataTypes.STRING,
    comment: 'Model'
  },
  specifications: {
    type: DataTypes.TEXT,
    comment: 'Teknik özellikler'
  }
}, {
  tableName: 'proforma_invoice_items',
  timestamps: true
});

// Model ilişkileri
ProformaInvoiceItem.associate = function(models) {
  // ProformaInvoiceItem -> ProformaInvoice (N:1)
  ProformaInvoiceItem.belongsTo(models.ProformaInvoice, {
    foreignKey: 'proformaInvoiceId',
    as: 'ProformaInvoice'
  });

  // ProformaInvoiceItem -> QuoteItem (N:1)
  ProformaInvoiceItem.belongsTo(models.QuoteItem, {
    foreignKey: 'quoteItemId',
    as: 'QuoteItem'
  });
};

return ProformaInvoiceItem;
};
