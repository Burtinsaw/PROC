'use strict';
const { Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  class Invoice extends Model {
    static associate(models) {
      this.belongsTo(models.PurchaseOrder, { foreignKey: 'purchaseOrderId', as: 'purchaseOrder' });
      this.belongsTo(models.Shipment, { foreignKey: 'shipmentId', as: 'shipment' });
      this.hasMany(models.Payment, { foreignKey: 'invoiceId', as: 'payments' });
      this.belongsTo(models.User, { foreignKey: 'createdById', as: 'createdBy' });
    }
  }

  Invoice.init({
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    invoiceNumber: { type: DataTypes.STRING, unique: true, allowNull: false },
    purchaseOrderId: { type: DataTypes.INTEGER, allowNull: false },
    shipmentId: { type: DataTypes.INTEGER },
    supplierInvoiceNumber: { type: DataTypes.STRING },
    invoiceDate: { type: DataTypes.DATE, allowNull: false },
    dueDate: { type: DataTypes.DATE },
    status: {
      type: DataTypes.ENUM,
      values: ['draft', 'sent', 'approved', 'paid', 'overdue', 'cancelled'],
      defaultValue: 'draft'
    },
    subtotal: { type: DataTypes.DECIMAL(15, 2), allowNull: false },
    taxRate: { type: DataTypes.DECIMAL(5, 2), defaultValue: 0 },
    taxAmount: { type: DataTypes.DECIMAL(15, 2), defaultValue: 0 },
    totalAmount: { type: DataTypes.DECIMAL(15, 2), allowNull: false },
    paidAmount: { type: DataTypes.DECIMAL(15, 2), defaultValue: 0 },
    remainingAmount: { type: DataTypes.DECIMAL(15, 2) },
    currency: { type: DataTypes.STRING, defaultValue: 'USD' },
    paymentTerms: { type: DataTypes.STRING },
    notes: { type: DataTypes.TEXT },
    createdById: { type: DataTypes.INTEGER, allowNull: false },
    // ID Takip Sistemi
    trackingId: { 
      type: DataTypes.STRING,
      comment: 'Takip ID - Proforma onaylandığında proforma numarası'
    }
  }, {
    sequelize,
    modelName: 'Invoice',
    tableName: 'invoices',
    timestamps: true
  });

  return Invoice;
};
