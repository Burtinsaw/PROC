'use strict';
const { Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  class RFQ extends Model {
    static associate(models) {
      // Bir RFQ bir talepten oluşur
      this.belongsTo(models.Talep, { foreignKey: 'talepId', as: 'talep' });
      // RFQ'yu oluşturan kullanıcı
      this.belongsTo(models.User, { foreignKey: 'createdById', as: 'createdBy' });
      // RFQ items - hangi ürünler için teklif isteniyor
      this.hasMany(models.RFQItem, { foreignKey: 'rfqId', as: 'items' });
      // RFQ'ya gelen teklifler
      this.hasMany(models.Quote, { foreignKey: 'rfqId', as: 'quotes' });
      // RFQ'nun gönderildiği tedarikçiler
      this.belongsToMany(models.Company, { 
        through: 'RFQSuppliers', 
        foreignKey: 'rfqId', 
        otherKey: 'supplierId',
        as: 'suppliers' 
      });
    }
  }

  RFQ.init({
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    rfqNumber: { type: DataTypes.STRING, unique: true, allowNull: false }, // RFQ-2025-001
    title: { type: DataTypes.STRING, allowNull: false },
    description: { type: DataTypes.TEXT },
    talepId: { type: DataTypes.INTEGER, allowNull: true },
    status: {
      type: DataTypes.ENUM,
      values: ['draft', 'sent', 'responses_received', 'evaluation', 'completed', 'cancelled'],
      defaultValue: 'draft'
    },
    deadline: { type: DataTypes.DATE, allowNull: true },
    currency: { type: DataTypes.STRING, defaultValue: 'USD' },
    paymentTerms: { type: DataTypes.STRING },
    deliveryTerms: { type: DataTypes.STRING },
    validityPeriod: { type: DataTypes.INTEGER, defaultValue: 30 }, // gün
    notes: { type: DataTypes.TEXT },
    createdById: { type: DataTypes.INTEGER, allowNull: false },
    sentDate: { type: DataTypes.DATE },
    evaluationCompleted: { type: DataTypes.DATE }
  }, {
    sequelize,
    modelName: 'RFQ',
    tableName: 'rfqs',
    timestamps: true
  });

  return RFQ;
};
